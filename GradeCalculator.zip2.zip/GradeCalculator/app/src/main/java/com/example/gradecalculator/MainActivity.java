package com.example.gradecalculator;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        final EditText x =findViewById(R.id.editTextTextPersonName);
        final EditText y =findViewById(R.id.editTextTextPersonName2);
        final EditText z =findViewById(R.id.editTextTextPersonName3);
        final EditText v =findViewById(R.id.editTextTextPersonName4);
        Button g =findViewById(R.id.button);
        Button reset = findViewById(R.id.button2);
        final TextView p =findViewById(R.id.textView6);

        g.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int a = Integer.parseInt(x.getText().toString());
                int b = Integer.parseInt(y.getText().toString());
                int c = Integer.parseInt(z.getText().toString());
                int d = Integer.parseInt(v.getText().toString());
                int amal = a + b + c + d;
                p.setText(amal+"");
            }
        });

        reset.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                x.setText("");
                y.setText("");
                z.setText("");
                v.setText("");
            }
        });
    }
}